const express=require('express'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),cookieParser=require('cookie-parser'),crypto=require('crypto'),path=require('path'),fs=require('fs');
const PORT=process.env.PORT||3000,DIR=process.env.DATA_DIR||__dirname,PROD=process.env.NODE_ENV==='production';
fs.mkdirSync(DIR,{recursive:true});
const sf=path.join(DIR,'.secret');
const SECRET=process.env.JWT_SECRET||(fs.existsSync(sf)?fs.readFileSync(sf,'utf8'):(()=>{const s=crypto.randomBytes(32).toString('hex');fs.writeFileSync(sf,s);return s})());
const db=new Database(path.join(DIR,'loja.db'));db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,phone TEXT,pass TEXT,role TEXT DEFAULT 'cliente',created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT,category TEXT,description TEXT,price REAL,image TEXT,sizes TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user_id INTEGER,status TEXT DEFAULT 'pendente',total REAL,items TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS visits(day TEXT PRIMARY KEY,n INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);`);
const getS=k=>db.prepare('SELECT v FROM settings WHERE k=?').get(k)?.v;
const setS=(k,v)=>db.prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k,v);
if(getS('whatsapp')===undefined)setS('whatsapp',process.env.WHATSAPP||'5581989033691');
if(process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD){
  const e=process.env.ADMIN_EMAIL.toLowerCase(),h=bcrypt.hashSync(process.env.ADMIN_PASSWORD,10);
  db.prepare(`INSERT INTO users(name,email,pass,role) VALUES('Administrador',?,?,'admin') ON CONFLICT(email) DO UPDATE SET pass=excluded.pass,role='admin'`).run(e,h);
}else if(!db.prepare("SELECT 1 FROM users WHERE role='admin'").get())console.warn('ATENÇÃO: defina ADMIN_EMAIL e ADMIN_PASSWORD para criar o administrador.');
if(!db.prepare('SELECT 1 FROM products').get()){
  const ins=db.prepare('INSERT INTO products(name,category,description,price,image,sizes) VALUES(?,?,?,?,?,?)');
  [['Camiseta Básica Preta','Camisetas','Algodão premium, corte reto.',59.9,{P:5,M:8,G:4}],['Calça Alfaiataria','Calças','Caimento elegante para o dia a dia.',149.9,{36:3,38:5,40:2}],['Vestido Midi Preto','Vestidos','Tecido leve com acabamento fino.',189.9,{P:2,M:4,G:2}],['Bermuda Sarja Branca','Bermudas','Confortável e versátil.',99.9,{38:4,40:4}]].forEach(p=>ins.run(p[0],p[1],p[2],p[3],'',JSON.stringify(p[4])));
}
const app=express();app.set('trust proxy',1);
app.use((q,s,n)=>{s.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin'});n()});
app.use(express.json({limit:'4mb'}),cookieParser());
const h=f=>(req,res)=>{try{f(req,res)}catch(e){res.status(e.status||400).json({error:e.message})}};
const sign=u=>jwt.sign({id:u.id},SECRET,{expiresIn:'7d'});
const setC=(res,u)=>res.cookie('t',sign(u),{httpOnly:true,sameSite:'strict',secure:PROD,maxAge:6048e5});
app.use('/api',(req,res,next)=>{try{const{id}=jwt.verify(req.cookies.t,SECRET);req.user=db.prepare('SELECT id,name,email,phone,role FROM users WHERE id=?').get(id)}catch{}next()});
const need=(req,res,next)=>req.user?next():res.status(401).json({error:'Faça login para continuar'});
const admin=(req,res,next)=>req.user?.role==='admin'?next():res.status(403).json({error:'Acesso negado'});
const tries=new Map();
const limit=req=>{const n=(tries.get(req.ip)||[]).filter(t=>Date.now()-t<9e5);if(n.length>=10)throw new Error('Muitas tentativas. Aguarde 15 minutos.');n.push(Date.now());tries.set(req.ip,n)};
const online=new Map(),day=()=>new Date().toISOString().slice(0,10);

app.get('/api/config',h((q,r)=>r.json({whatsapp:getS('whatsapp')||''})));
app.get('/api/me',h((q,r)=>r.json(q.user||null)));
app.post('/api/ping',h((q,r)=>{online.set(String(q.body.vid||'').slice(0,40),Date.now());if(q.body.first)db.prepare('INSERT INTO visits(day,n) VALUES(?,1) ON CONFLICT(day) DO UPDATE SET n=n+1').run(day());r.json({ok:1})}));
app.post('/api/register',h((q,r)=>{limit(q);const{name,email,phone,password}=q.body;
  if(!String(name||'').trim()||!/^\S+@\S+\.\S+$/.test(email||''))throw new Error('Nome e e-mail válidos são obrigatórios');
  if(String(password||'').length<8)throw new Error('A senha deve ter ao menos 8 caracteres');
  try{const x=db.prepare("INSERT INTO users(name,email,phone,pass) VALUES(?,?,?,?)").run(String(name).trim().slice(0,80),email.toLowerCase(),String(phone||'').slice(0,20),bcrypt.hashSync(password,10));
    const u=db.prepare('SELECT id,name,email,phone,role FROM users WHERE id=?').get(x.lastInsertRowid);setC(r,u);r.json(u)}
  catch{throw new Error('E-mail já cadastrado')}}));
app.post('/api/login',h((q,r)=>{limit(q);const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(q.body.email||'').toLowerCase());
  if(!u||!bcrypt.compareSync(String(q.body.password||''),u.pass))throw new Error('E-mail ou senha incorretos');
  setC(r,u);r.json({id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role})}));
app.post('/api/logout',(q,r)=>{r.clearCookie('t');r.json({ok:1})});

const pub=()=>db.prepare('SELECT id,name,category,description,price,sizes,length(image) iv FROM products ORDER BY id DESC').all().map(p=>({...p,sizes:JSON.parse(p.sizes)}));
app.get('/api/products',h((q,r)=>r.json(pub())));
app.get('/img/:id',(q,r)=>{const p=db.prepare('SELECT image FROM products WHERE id=?').get(q.params.id);const m=p?.image?.match(/^data:image\/(png|jpeg|webp);base64,(.+)$/);if(!m)return r.sendStatus(404);r.type('image/'+m[1]).set('Cache-Control','public,max-age=86400').send(Buffer.from(m[2],'base64'))});

const prod=b=>{const sizes={};for(const[k,v]of Object.entries(b.sizes||{})){const n=parseInt(v);if(String(k).length&&String(k).length<=8&&n>=0)sizes[String(k).toUpperCase()]=n}
  const price=Math.round(Number(b.price)*100)/100;if(!String(b.name||'').trim()||!(price>=0))throw new Error('Nome e preço válidos são obrigatórios');
  let image=null;if(typeof b.image==='string'){if(b.image&&(!/^data:image\/(png|jpeg|webp);base64,/.test(b.image)||b.image.length>2e6))throw new Error('Imagem inválida ou grande demais');image=b.image}
  return{a:[String(b.name).trim().slice(0,100),String(b.category||'Outras').slice(0,30),String(b.description||'').slice(0,1000),price],image,sizes:JSON.stringify(sizes)}};
app.post('/api/admin/products',admin,h((q,r)=>{const p=prod(q.body);r.json({id:db.prepare('INSERT INTO products(name,category,description,price,image,sizes) VALUES(?,?,?,?,?,?)').run(...p.a,p.image||'',p.sizes).lastInsertRowid})}));
app.put('/api/admin/products/:id',admin,h((q,r)=>{const p=prod(q.body);db.prepare('UPDATE products SET name=?,category=?,description=?,price=?,image=COALESCE(?,image),sizes=? WHERE id=?').run(...p.a,p.image,p.sizes,q.params.id);r.json({ok:1})}));
app.delete('/api/admin/products/:id',admin,h((q,r)=>{db.prepare('DELETE FROM products WHERE id=?').run(q.params.id);r.json({ok:1})}));

const mk=db.transaction((uid,items)=>{let total=0;const out=[];
  for(const it of Array.isArray(items)?items:[]){const p=db.prepare('SELECT * FROM products WHERE id=?').get(it.id);if(!p)throw new Error('Produto indisponível');
    const s=JSON.parse(p.sizes),n=parseInt(it.qty);if(!(n>0)||!(s[it.size]>=n))throw new Error(`Estoque insuficiente: ${p.name} (${it.size})`);
    s[it.size]-=n;db.prepare('UPDATE products SET sizes=? WHERE id=?').run(JSON.stringify(s),p.id);total+=p.price*n;out.push({id:p.id,name:p.name,size:it.size,qty:n,price:p.price})}
  if(!out.length)throw new Error('Carrinho vazio');total=Math.round(total*100)/100;
  return{id:db.prepare('INSERT INTO orders(user_id,total,items) VALUES(?,?,?)').run(uid,total,JSON.stringify(out)).lastInsertRowid,total,items:out}});
app.post('/api/orders',need,h((q,r)=>r.json(mk(q.user.id,q.body.items))));
app.get('/api/my-orders',need,h((q,r)=>r.json(db.prepare('SELECT id,status,total,items,created FROM orders WHERE user_id=? ORDER BY id DESC').all(q.user.id).map(o=>({...o,items:JSON.parse(o.items)})))));
app.get('/api/admin/orders',admin,h((q,r)=>r.json(db.prepare('SELECT o.*,u.name,u.email,u.phone FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.id DESC').all().map(o=>({...o,items:JSON.parse(o.items)})))));
const ST=['pendente','confirmado','concluido','cancelado'];
app.put('/api/admin/orders/:id',admin,h((q,r)=>{if(!ST.includes(q.body.status))throw new Error('Status inválido');
  db.transaction(()=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(q.params.id);if(!o)throw new Error('Pedido não encontrado');if(o.status==='cancelado')throw new Error('Pedido já cancelado');
    if(q.body.status==='cancelado')for(const i of JSON.parse(o.items)){const p=db.prepare('SELECT sizes FROM products WHERE id=?').get(i.id);if(p){const s=JSON.parse(p.sizes);s[i.size]=(s[i.size]||0)+i.qty;db.prepare('UPDATE products SET sizes=? WHERE id=?').run(JSON.stringify(s),i.id)}}
    db.prepare('UPDATE orders SET status=? WHERE id=?').run(q.body.status,o.id)})();r.json({ok:1})}));
app.put('/api/admin/config',admin,h((q,r)=>{setS('whatsapp',String(q.body.whatsapp||'').replace(/\D/g,''));r.json({ok:1})}));

app.get('/api/admin/stats',admin,h((q,r)=>{
  for(const[k,t]of online)if(Date.now()-t>35000)online.delete(k);
  const days=[...Array(14)].map((_,i)=>new Date(Date.now()-(13-i)*864e5).toISOString().slice(0,10));
  const orders=db.prepare('SELECT * FROM orders').all(),live=orders.filter(o=>o.status!=='cancelado'),sold=orders.filter(o=>['confirmado','concluido'].includes(o.status));
  const vis=Object.fromEntries(db.prepare('SELECT * FROM visits').all().map(v=>[v.day,v.n])),top={};
  live.forEach(o=>JSON.parse(o.items).forEach(i=>{top[i.name]=(top[i.name]||0)+i.qty}));
  const stock=pub().map(p=>({name:p.name,total:Object.values(p.sizes).reduce((a,b)=>a+b,0)}));
  const sum=(arr,d)=>Math.round(arr.filter(o=>o.created.startsWith(d)).reduce((a,o)=>a+o.total,0)*100)/100;
  r.json({online:online.size,visits:db.prepare('SELECT COALESCE(SUM(n),0) n FROM visits').get().n,users:db.prepare("SELECT COUNT(*) n FROM users WHERE role='cliente'").get().n,
    orders:live.length,revenue:Math.round(sold.reduce((a,o)=>a+o.total,0)*100)/100,
    status:Object.fromEntries(ST.map(s=>[s,orders.filter(o=>o.status===s).length])),
    top:Object.entries(top).sort((a,b)=>b[1]-a[1]).slice(0,5),stock,
    visitSeries:days.map(d=>({d,v:vis[d]||0})),salesSeries:days.map(d=>({d,v:sum(sold,d)})),
    recent:orders.slice(-5).reverse().map(o=>({id:o.id,total:o.total,status:o.status,created:o.created}))})}));

app.use(express.static(path.join(__dirname,'public')));
app.listen(PORT,()=>console.log('ARTHUR ROUPAS rodando na porta '+PORT));
