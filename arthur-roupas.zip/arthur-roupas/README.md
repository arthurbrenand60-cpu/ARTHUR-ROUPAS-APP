# ARTHUR ROUPAS — Loja online

Node.js + Express + SQLite (banco de dados em arquivo) + HTML/CSS/JS.

## 1. Configurar (no seu computador)
1. Instale o Node.js (versão 18 ou superior): https://nodejs.org
2. Abra o terminal na pasta do projeto e rode: `npm install`
3. Crie o administrador definindo e-mail e senha forte:
   - Mac/Linux: `ADMIN_EMAIL=voce@email.com ADMIN_PASSWORD='SuaSenhaForte123' npm start`
   - Windows (PowerShell): `$env:ADMIN_EMAIL="voce@email.com"; $env:ADMIN_PASSWORD="SuaSenhaForte123"; npm start`
4. Abra http://localhost:3000

## 2. Testar
- Entrar com o e-mail/senha de administrador → aparece o link "Admin".
- Admin > Configurações: coloque o WhatsApp da loja (código do país + DDD + número, só dígitos).
- Admin > Produtos: cadastre produto com foto, preço e tamanhos no formato `P:5, M:3, G:2` (tamanho:estoque).
- Abra uma aba anônima: crie uma conta de cliente, adicione ao carrinho e clique em "Finalizar pelo WhatsApp".
- Volte ao Admin: Pedidos (mude o status), Estatísticas (online, acessos, vendas, gráficos).
- Feche e reabra o servidor: os dados continuam (arquivo `loja.db`).

## 3. Publicar online
O banco é um arquivo, então a hospedagem precisa de **disco persistente**.
Opção simples: Railway ou Render (com Disk/Volume) ou uma VPS.
1. Envie a pasta para um repositório no GitHub (o `.gitignore` já protege o banco e segredos).
2. Crie um serviço "Web Service" a partir do repositório. Build: `npm install`. Start: `npm start`.
3. Variáveis de ambiente:
   - `NODE_ENV=production`
   - `ADMIN_EMAIL` e `ADMIN_PASSWORD` (a senha é atualizada a cada início)
   - `JWT_SECRET` = texto aleatório longo
   - `DATA_DIR` = pasta do disco persistente (ex.: `/data`)
4. Adicione o disco/volume montado no mesmo caminho do `DATA_DIR`.
5. Use o endereço HTTPS fornecido (ou conecte seu domínio). Sem disco persistente, os dados somem a cada reinício.
6. Faça backup periódico de `loja.db`.

## Segurança implementada
Senhas com bcrypt; sessão em cookie httpOnly + SameSite=Strict (+Secure em produção); rotas admin validadas no servidor;
preços e estoque sempre calculados no servidor; limite de tentativas de login; saída HTML escapada (anti-XSS).
Cadastro de clientes nunca cria administradores.
